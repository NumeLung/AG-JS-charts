<!DOCTYPE html>
<html lang="en">
<head>
    <title>AG Charts Basic Example</title>
    <script src="https://cdn.jsdelivr.net/npm/ag-charts-community/dist/ag-charts-community.min.js">
    </script>
</head>
<body>
    <div id="myChart" style="position: absolute; top: 0; right: 0; bottom: 0; left: 0;"></div>
    <?php include_once "load_info_columns.php"; ?>
    <script>
        const data = <?= json_encode($data,JSON_HEX_TAG); ?>;
        const options = {
            container: document.getElementById('myChart'),
            data: data,
            title: {
                text: 'Total Sales'
            },
            subtitle: {
                text: 'per month'
            },
            footnote: {
                text: 'Based by all sales for a certain year'
            },
            padding: {
                top: 40,
                right: 40,
                bottom: 40,
                left: 40
            },
            series: [
                { type: 'column', xKey: 'date', yKey: 'Sales', stacked: false },
                { type: 'column', xKey: 'date', yKey: 'Quantity', stacked: false }
            ],
            legend: {
                spacing: 40
            },
        };
        agCharts.AgChart.create(options);
    </script>
</body>
</html>



