<?php include_once "load_info_lines.php" ?>
<!DOCTYPE html>

<html lang="en">
<head>
    <title>JavaScript example</title>
    <meta charSet="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <style media="only screen">
        html, body {
            height: 100%;
            width: 100%;
            margin: 0;
            box-sizing: border-box;
            -webkit-overflow-scrolling: touch;
        }

        html {
            position: absolute;
            top: 0;
            left: 0;
            padding: 0;
            overflow: auto;
        }

        body {
            padding: 1rem;
            overflow: auto;
        }
    </style>
</head>
<body>
    <div id="myChart" style="height: 100%">
    </div>
    <script>var __basePath = './';</script>
    <script src="https://cdn.jsdelivr.net/npm/ag-charts-community@8.0.6/dist/ag-charts-community.min.js"></script>
    <script>
        /** @type {import('ag-charts-community').AgChartOptions} */
        const options = {
            container: document.getElementById('myChart'),
            autoSize: true,
            title: {
                text: 'Top 10 products sold by month of the year 1998',
            },
            data: <?= $jsonData1 ?>,

            series:
                <?php
                /*foreach ($aResult as $entry) {
                $yKeys = [];
                foreach ($entry as $property => $value) {
                    if ($property !== 'month') {
                        $yKeys[] = "'$property'";
                    }
                }
                echo "{\n";
                echo "  xKey: 'month',\n";
                echo "  yKey: " . implode(", ", $yKeys) . "\n";
                echo "},\n";
                }*/
                /*$series = [];
                foreach ($aResult as $entry) {
                    $yKeys = [];
                    foreach ($entry as $property => $value) {
                        if ($property !== 'month') {
                            $yKeys[] = "'$property'";
                        }
                    }
                    $series[] = [
                            "xKey" => 'month',
                            "yKey" => implode(", ", $yKeys)
                    ];
                }
                echo json_encode($series,JSON_HEX_APOS);*/
                /*foreach ($aResult as $entry) {
                    $yKeys = [];
                    foreach ($entry as $property => $value) {
                        if ($property !== 'month') {
                            $property = str_replace("'", "\'", $property);
                            $yKeys[] = "'$property'";
                        }
                    }
                    echo "{\n";
                    echo "  xKey: 'month',\n";
                    echo "  yKey: " . implode(", ", $yKeys) . "\n";
                    echo "},\n";
                }*/
                echo json_encode($series);
                ?>
        };
        agCharts.AgChart.create(options);
    </script>
</body>
</html>